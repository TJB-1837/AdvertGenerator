---
name: Adrafteo Workspace
colors:
  surface: '#faf8ff'
  surface-dim: '#d6d9eb'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e4e7fa'
  surface-container-highest: '#dfe2f4'
  on-surface: '#171b28'
  on-surface-variant: '#574240'
  inverse-surface: '#2c303e'
  inverse-on-surface: '#eef0ff'
  outline: '#8a716f'
  outline-variant: '#dec0bd'
  surface-tint: '#a53937'
  primary: '#902929'
  on-primary: '#ffffff'
  primary-container: '#b0413e'
  on-primary-container: '#ffdedb'
  inverse-primary: '#ffb3ae'
  secondary: '#775a00'
  on-secondary: '#ffffff'
  secondary-container: '#feca47'
  on-secondary-container: '#725500'
  tertiary: '#2d5815'
  on-tertiary: '#ffffff'
  tertiary-container: '#45712b'
  on-tertiary-container: '#bff49e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad7'
  primary-fixed-dim: '#ffb3ae'
  on-primary-fixed: '#410004'
  on-primary-fixed-variant: '#852222'
  secondary-fixed: '#ffdf9a'
  secondary-fixed-dim: '#f2bf3c'
  on-secondary-fixed: '#251a00'
  on-secondary-fixed-variant: '#5a4300'
  tertiary-fixed: '#bdf19c'
  tertiary-fixed-dim: '#a2d582'
  on-tertiary-fixed: '#082100'
  on-tertiary-fixed-variant: '#26500d'
  background: '#faf8ff'
  on-background: '#171b28'
  surface-variant: '#dfe2f4'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
  code-md:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies a modern Scandinavian functionalist aesthetic tailored for high-volume marketplace sellers and inventory curators. The visual language blends airy minimalism with warm, tactile editorial accents to evoke productivity, calm efficiency, and precision craftsmanship.

By eschewing the sterility of typical enterprise software in favor of grounded, earthy accents (rust, warm honey, and sage) anchored on an alabaster foundation, the interface transforms listing creation and multi-item batch management into an inviting, deliberate ritual. 

Layouts leverage structured whitespace, ultra-crisp hairline dividers, and deliberate information density to prevent cognitive fatigue while maintaining fast parsing of variables, lot inventories, and SEO signals.

## Colors

The palette draws inspiration from mid-century Scandinavian paper goods and functional studio workshops. 

- **Primary Accent (`#B0413E` - Rust/Terracotta):** Reserved for primary interactive intents, active navigation states, high-priority draft publishing triggers, and key brand accents.
- **Secondary Accent (`#FFCB47` - Honey Gold):** Used specifically for syntax token highlights in bracket-variable templates (`{brand}`, `{condition}`, `{material}`), status warnings, and inline draft completion meters.
- **Tertiary Accent (`#6A994E` - Olive Sage):** Applied to commercial proof indicators—ROI metrics, profit calculations, successful cross-listing checks, and "Sold / Active" badges.
- **Neutral Foreground (`#333745` - Charcoal Slate):** The singular source of truth for high-contrast typographic hierarchy and hairline structural elements.
- **Neutral Surface System:** The canvas sits on a gentle Alabaster tint (`#F5EDF0`), layered over with pure `#FFFFFF` work surfaces, cards, and modal sheets to introduce crisp figure-ground separation without harsh digital glare. Hairline borders are tinted with subtle charcoal opacity (`rgba(51, 55, 69, 0.08)`) or tinted alabaster border tones (`#E2D9DC`).

## Typography

The design system employs **Plus Jakarta Sans** as the unified type family across all display, text, and interface layers. Its clean geometric underpinning and open counters ensure pristine readability in dense inventory tables, while subtle humanist nuances preserve brand warmth.

For syntax handling—specifically reusable bracket variables like `{title_prefix}`, `{size}`, or `{location_tag}`—the system introduces **Space Mono** (`code-md`). This monospaced contrast visually isolates template tokens from freeform listing copy, preventing input error during batch configuration.

## Layout & Spacing

The layout is built around a fluid top-anchored app shell, moving seamlessly from mobile views to ultra-wide desktop monitors.

- **Workspace Top Bar:** Fixed-height (64px) horizontal navigation containing global workspace tabs, seller profile switcher, platform connection badges (eBay, Vinted, Leboncoin, Etsy), and global search.
- **Desktop Grid (1024px+):** A 12-column layout with 24px (`1.5rem`) gutters and 32px (`2rem`) side margins. For listing drafting modes, the grid cleanly splits into a 7-column template canvas and a 5-column live preview / inventory lot inspector.
- **Tablet Grid (768px - 1023px):** An 8-column layout with 16px gutters, stacking complex split views into toggleable preview tabs.
- **Mobile Grid (<768px):** A 4-column layout with 16px margins, collapsing the top tab bar into a horizontally scrollable pill rail.

## Elevation & Depth

Visual hierarchy relies on Scandinavian plane separation—stacking pure white `#FFFFFF` surfaces against the soft `#F5EDF0` canvas—reinforced with hairline framing borders rather than heavy, drop-shadow elevations.

- **Level 0 (App Canvas):** `#F5EDF0` base background.
- **Level 1 (Cards, Worksheets, Panels):** `#FFFFFF` surfaces bounded by a crisp 1px hairline border (`#E2D9DC`). Shadows are practically non-existent or restricted to a subtle ambient contact tint: `box-shadow: 0 1px 3px rgba(51, 55, 69, 0.04)`.
- **Level 2 (Dropdowns, Popovers, Floating Variable Pickers):** `#FFFFFF` surfaces layered with `box-shadow: 0 8px 24px -4px rgba(51, 55, 69, 0.08)` and bordered with `rgba(51, 55, 69, 0.12)`.
- **Level 3 (Modals, Slide-over Inventory Drawers):** High-level focal points with backdrop dimming (`rgba(51, 55, 69, 0.40)` with a 4px blur) and `box-shadow: 0 16px 40px -8px rgba(51, 55, 69, 0.16)`.

## Shapes

The design system maintains a calibrated geometry balancing utility with organic soft edges:

- **Standard Containers & Cards:** Configured with `0.5rem` (8px) corners to provide distinct, modern containment for complex table cells, multi-item lots, and form modules.
- **Larger Sheets, Modals, and Canvas Modules:** Scale up to `1rem` (16px / `rounded-lg`) for structural softness.
- **Pills & Chips:** Fully rounded (`9999px`) for marketplace destination tags, variable indicators, and status chips, creating immediate contrast against rectangular input containers.

## Components

### Buttons
- **Primary:** Background `#B0413E`, text `#FFFFFF`, 8px radius, horizontal padding 16px, vertical padding 10px. Subtle hover darkening to `#9C3734`. No heavy drop shadows.
- **Secondary / Outline:** Background `#FFFFFF`, 1px border `#E2D9DC`, text `#333745`. Hover state swaps border to `#333745` and subtle tint `#F5EDF0`.
- **Subtle / Ghost:** Transparent background, text `#333745`, hover background `rgba(51, 55, 69, 0.05)`.
- **Accent (Publish / Push to Live):** Background `#6A994E`, text `#FFFFFF`, used strictly for confirmed multi-platform broadcasts.

### Variable Token Chips & Badges
- **Bracket Variables (`{variable}`):** Capsule pills featuring `#FFCB47` tinted background (`rgba(255, 203, 71, 0.22)`), 1px solid `rgba(255, 203, 71, 0.60)`, text `#333745`, rendered in `Space Mono` 12px. Interactive when clicked within templates.
- **Marketplace Badges:** Compact pills with platform colors and logos (eBay, Etsy, Vinted, Leboncoin), bordered with `#E2D9DC` on an Alabaster fill.
- **Performance / Metric Badges:** Sage green surface tint (`rgba(106, 153, 78, 0.15)`) with `#6A994E` bold numerical indicators.

### Inputs & Textareas
- **Default State:** Background `#FFFFFF`, border 1px solid `#E2D9DC`, 8px border radius, text `#333745`, placeholder `#33374566`.
- **Focus State:** Border 1px solid `#B0413E`, ambient ring `0 0 0 3px rgba(176, 65, 62, 0.12)`.
- **Template Editor Field:** Rich-text surface capable of rendering inline non-breaking variable pills alongside plain body text.

### Selection Controls (Checkboxes & Radios)
- **Checkboxes:** 18px square with 4px border radius. Inactive: 1px border `#33374530`. Checked: `#B0413E` fill with crisp white checkmark.
- **Radio Buttons:** 18px circle. Checked: 2px solid `#B0413E` border with internal `#B0413E` 8px core.

### Cards & Multi-Item Lot Tables
- **Cards:** Crisp `#FFFFFF` surface with 1px border `#E2D9DC`, 16px internal padding (`space-md`), and explicit section dividing lines in `rgba(51, 55, 69, 0.06)`.
- **Data Rows:** Alternating hover highlight using `rgba(245, 237, 240, 0.5)` with monospaced SKU and stock counts.

### Top Bar Workspace Navigation
- **Height & Style:** 64px structural white header with bottom hairline border `#E2D9DC`.
- **Navigation Tabs:** Horizontal text links with 14px label weight. Active tab features an underline pill in `#B0413E` positioned exactly flush to the bottom border.